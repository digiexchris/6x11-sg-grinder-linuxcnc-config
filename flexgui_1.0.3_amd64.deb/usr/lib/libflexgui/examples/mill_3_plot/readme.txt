Copy the .ngc files

zero_material_x.ngc
zero_material_y.ngc
zero_vise_x.ngc
zero_vise_y.ngc

to the /user/linuxcnc/nc_files folder for the MDI_COMMAND buttons to work.
